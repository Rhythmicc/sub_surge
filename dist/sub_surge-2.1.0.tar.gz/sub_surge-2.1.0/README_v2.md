# Surge 订阅配置管理工具 v2.0

> 🎉 全新重构！配置驱动、Web管理、无需编程  
> 🤖 支持 AI 增强分析，智能生成配置

## ✨ 新特性

### v2.0 重大更新

- **🔧 配置驱动**: 不再需要编写Python代码，通过配置文件管理所有机场
- **🌐 Web界面**: 提供美观易用的Web管理界面，轻松管理订阅
- **🤖 AI分析**: 智能分析订阅内容，自动生成最佳配置（支持OpenRouter模型）
- **📊 模板系统**: 预置多种机场模板，快速配置
- **🔄 一键迁移**: 从旧版本无缝迁移到新版本
- **🎨 自定义**: 支持高级配置，满足各种需求
- **📱 RESTful API**: 完整的API接口，支持集成

## 📦 安装

```bash
pip install git+https://github.com/Rhythmicc/sub_surge.git -U
```

## 🚀 快速开始

### 方式一：Web管理界面（推荐）

1. 启动Web服务:
   ```bash
   sub-surge serve
   ```

2. 打开浏览器访问: `http://localhost:8000`

3. 在Web界面中:
   - 添加机场配置
   - **🔍 使用智能分析**: 填写订阅链接后点击"智能分析"按钮，AI自动推荐配置
   - 选择合适的模板
   - 填写订阅信息
   - 一键更新订阅

> 💡 **智能分析功能**: 系统会自动分析订阅内容，识别节点特征，推荐最佳配置。详见 [AI分析文档](docs/AI_ANALYSIS.md)

### 方式二：命令行

1. 添加机场:
   ```bash
   sub-surge add \
     --name "Amy" \
     --show-name "Amy机场" \
     --url "https://example.com/subscribe" \
     --key "airport/amy.conf" \
     --template "generic"
   ```

2. 更新订阅:
   ```bash
   sub-surge update Amy
   ```

3. 查看所有机场:
   ```bash
   sub-surge list
   ```

## 🔄 从旧版本迁移

如果你之前使用的是需要编写Python代码的旧版本，可以一键迁移:

```bash
sub-surge migrate
```

迁移工具会:
- ✅ 自动识别旧配置文件
- ✅ 分析Python解析器代码
- ✅ 转换为新的配置格式
- ✅ 创建配置备份
- ✅ 保留所有机场设置

## 📖 使用指南

### 配置模板

工具提供了多种预置模板：

#### Generic模板（通用）
适用于大多数机场，支持基本的国家名称映射和节点过滤。

#### Nexitally模板
针对Nexitally机场优化，包含完整的国家名称映射。

### 🤖 智能分析功能

**自动配置生成，告别手动填写！**

1. **填写订阅链接**
2. **点击"🔍 智能分析"按钮**
3. **查看AI分析结果**：
   - 节点数量和国家分布
   - 推荐的模板类型
   - 建议的机场名称
   - 自动识别的配置参数
4. **点击"✨ 应用推荐配置"一键应用**

详细配置请参考: [AI增强分析文档](docs/AI_ANALYSIS.md)

### 命令行完整参考

```bash
# 启动Web服务
sub-surge serve [--host HOST] [--port PORT]

# 添加机场
sub-surge add \
  --name NAME \           # 机场名称（唯一标识）
  --show-name SHOW_NAME \ # 显示名称
  --url URL \             # 订阅链接
  --key KEY \             # 存储路径
  [--template TEMPLATE] \ # 模板类型
  [--reset-day DAYS]      # 重置周期

# 更新机场订阅
sub-surge update NAME [--local]  # --local: 只保存本地

# 合并多个机场
sub-surge merge

# 列出所有机场
sub-surge list

# 删除机场
sub-surge remove NAME

# 查看机场详情
sub-surge info NAME

# 全局配置管理
sub-surge config [KEY] [VALUE]

# 导出配置
sub-surge export [PATH]

# 导入配置
sub-surge import PATH

# 迁移旧配置
sub-surge migrate
```

### 配置文件说明

新版本使用JSON格式的配置文件，默认位置: `~/.sub_surge_config_v2.json`

配置文件结构:

```json
{
  "txcos_domain": "https://your-bucket.cos.region.myqcloud.com",
  "interval": 3600,
  "merge_key": "merge.conf",
  "merge_airports": ["Amy", "G94"],
  "airports": {
    "Amy": {
      "name": "Amy",
      "show_name": "Amy机场",
      "url": "https://example.com/subscribe",
      "key": "airport/amy.conf",
      "reset_day": 30,
      "is_node_list": false,
      "parser_config": {
        "country_name_mapping": {
          "Hong Kong": "香港",
          "USA": "美国"
        },
        "exclude_keywords": ["direct", "premium"]
      },
      "info_extractor": {
        "traffic_keywords": ["Bandwidth"],
        "reset_keywords": ["Reset"],
        "expire_keywords": ["Date"]
      }
    }
  }
}
```

### 高级配置

#### 自定义国家名称映射

在Web界面的"高级配置"中，可以自定义国家名称映射：

```json
{
  "Hong Kong": "香港",
  "USA": "美国",
  "Japan": "日本",
  "Singapore": "新加坡"
}
```

#### 节点过滤

使用排除关键词过滤不需要的节点：

```
direct, premium, expired
```

#### 正则表达式替换

支持使用正则表达式对节点名称进行复杂替换（配置文件中）：

```json
{
  "name_regex_replacements": [
    {
      "pattern": "\\s+",
      "replacement": " "
    }
  ]
}
```

## 🌐 Web管理界面

### 功能特点

- **📋 机场管理**: 添加、编辑、删除机场配置
- **🔄 一键更新**: 快速更新订阅
- **⚙️ 全局配置**: 管理COS域名、更新间隔等
- **📤 导入导出**: 备份和恢复配置
- **🎨 模板选择**: 快速应用预置模板
- **📊 实时预览**: 查看当前配置

### API接口

Web服务提供完整的REST API：

```
GET    /api/config              # 获取全局配置
PUT    /api/config              # 更新全局配置
GET    /api/config/export       # 导出配置
POST   /api/config/import       # 导入配置

GET    /api/airports            # 列出所有机场
GET    /api/airports/:name      # 获取机场详情
POST   /api/airports            # 添加机场
PUT    /api/airports/:name      # 更新机场配置
DELETE /api/airports/:name      # 删除机场
POST   /api/airports/:name/update  # 更新机场订阅

GET    /api/templates           # 获取所有模板
GET    /health                  # 健康检查
```

## 📝 配置示例

### 基本配置

```json
{
  "name": "MyAirport",
  "show_name": "我的机场",
  "url": "https://example.com/subscribe",
  "key": "airport/my.conf",
  "reset_day": 30
}
```

### 完整配置

```json
{
  "name": "MyAirport",
  "show_name": "我的机场",
  "url": "https://example.com/subscribe",
  "key": "airport/my.conf",
  "reset_day": 30,
  "is_node_list": false,
  "timezone_offset": 8,
  "panel_color": "#667eea",
  "parser_config": {
    "country_name_mapping": {
      "Hong Kong": "香港",
      "USA": "美国",
      "Japan": "日本"
    },
    "exclude_keywords": ["direct", "premium"],
    "name_regex_replacements": [
      {
        "pattern": "\\s+",
        "replacement": " "
      }
    ]
  },
  "info_extractor": {
    "traffic_keywords": ["Bandwidth", "流量"],
    "reset_keywords": ["Reset", "重置"],
    "expire_keywords": ["Date", "到期"],
    "traffic_pattern": null,
    "reset_pattern": null,
    "expire_pattern": null
  }
}
```

## 🔧 开发

### 项目结构

```
sub-surge/
├── sub_surge/
│   ├── __init__.py
│   ├── main_v2.py           # 新版命令行入口
│   ├── config_schema.py     # 配置Schema定义
│   ├── config_manager.py    # 配置管理器
│   ├── parser.py            # 配置驱动的解析器
│   ├── updater.py           # 订阅更新逻辑
│   ├── api.py               # FastAPI后端
│   ├── migration.py         # 迁移工具
│   └── template.py          # 配置模板
├── web/
│   ├── index.html           # Web界面
│   └── app.js               # 前端逻辑
├── pyproject.toml
└── README_v2.md
```

### 添加依赖

```bash
pip install fastapi uvicorn pydantic
```

### 启动开发服务器

```bash
cd sub-surge
python -m sub_surge.api
```

## ❓ 常见问题

### 1. 迁移后找不到机场？

检查迁移是否成功：
```bash
sub-surge list
```

如果列表为空，手动运行迁移：
```bash
sub-surge migrate
```

### 2. Web界面无法访问？

确认服务正在运行：
```bash
sub-surge serve
```

检查端口是否被占用，可以指定其他端口：
```bash
sub-surge serve --port 8080
```

### 3. 订阅更新失败？

1. 检查订阅链接是否正确
2. 确认网络连接正常
3. 查看详细错误信息：
   ```bash
   sub-surge info 机场名称
   ```

### 4. 如何自定义解析规则？

在Web界面的"高级配置"中，可以：
- 自定义国家名称映射
- 添加排除关键词
- 通过配置文件添加正则表达式替换

## 📄 许可证

MIT License

## 🤝 贡献

欢迎提交Issue和Pull Request！

## 📮 联系

- 作者: Rhythmicc
- 邮箱: rhythmlian.cn@gmail.com

---

**享受配置驱动的便利，告别编写代码！** 🎉
